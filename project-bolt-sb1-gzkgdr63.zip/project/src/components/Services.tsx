import React from 'react';
import { Brain, Workflow, BarChart, Shield, Clock, Zap } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Brain,
      title: 'Intelligent Process Automation',
      description: 'AI-powered workflows that learn and adapt to your business processes, eliminating manual tasks and reducing errors by up to 95%.',
      features: ['Smart Decision Making', 'Adaptive Learning', 'Error Reduction']
    },
    {
      icon: Workflow,
      title: 'Custom Automation Solutions',
      description: 'Tailored automation systems designed specifically for your industry, integrating seamlessly with your existing infrastructure.',
      features: ['Industry-Specific', 'Seamless Integration', 'Scalable Architecture']
    },
    {
      icon: BarChart,
      title: 'Advanced Analytics & Insights',
      description: 'Real-time monitoring and predictive analytics to optimize performance and identify opportunities for further automation.',
      features: ['Predictive Analytics', 'Real-time Monitoring', 'Performance Optimization']
    }
  ];

  const additionalFeatures = [
    { icon: Shield, title: 'Enterprise Security', description: 'Bank-grade security protocols' },
    { icon: Clock, title: '24/7 Operations', description: 'Round-the-clock automated processes' },
    { icon: Zap, title: 'Instant Deployment', description: 'Quick setup and implementation' }
  ];

  return (
    <section id="services" className="py-24 bg-gradient-to-b from-gray-900 to-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Revolutionary 
            <span className="text-gold"> AI Automation</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Transform your operations with cutting-edge automation solutions that deliver measurable results 
            and unprecedented efficiency gains.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <div
              key={index}
              className="group relative bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8 hover:border-gold/50 transition-all duration-300 transform hover:scale-105"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-gold/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl"></div>
              <div className="relative">
                <div className="w-16 h-16 bg-gradient-to-br from-gold to-gold/80 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <service.icon className="w-8 h-8 text-black" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-gold transition-colors duration-300">
                  {service.title}
                </h3>
                <p className="text-gray-300 mb-6 leading-relaxed">
                  {service.description}
                </p>
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-400">
                      <div className="w-2 h-2 bg-gold rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {additionalFeatures.map((feature, index) => (
            <div
              key={index}
              className="bg-black/40 border border-gray-700/30 rounded-xl p-6 text-center hover:border-gold/30 transition-all duration-300"
            >
              <feature.icon className="w-8 h-8 text-gold mx-auto mb-4" />
              <h4 className="text-lg font-semibold text-white mb-2">{feature.title}</h4>
              <p className="text-gray-400 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;