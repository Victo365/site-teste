import React from 'react';
import { ArrowRight, Clock, Target, Zap } from 'lucide-react';

const WorkflowTransformation = () => {
  const benefits = [
    {
      icon: Clock,
      title: 'Save Hours Daily',
      description: 'Automate repetitive tasks and focus on what truly matters to your business growth.'
    },
    {
      icon: Target,
      title: 'Precision & Accuracy',
      description: 'Eliminate human error with AI-powered processes that deliver consistent results.'
    },
    {
      icon: Zap,
      title: 'Instant Optimization',
      description: 'Real-time adjustments and improvements based on performance data and patterns.'
    }
  ];

  return (
    <section className="py-24 bg-gradient-to-b from-black to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Transform Your
              <span className="text-gold"> Daily Workflow</span>
            </h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              From morning coffee to complex business decisions, our AI automation seamlessly integrates 
              into your routine, enhancing productivity without disrupting your natural workflow.
            </p>
            
            <div className="space-y-6 mb-8">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start group">
                  <div className="w-12 h-12 bg-gradient-to-br from-gold/20 to-gold/10 rounded-xl flex items-center justify-center mr-4 border border-gold/30 group-hover:border-gold/50 transition-all duration-300">
                    <benefit.icon className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-gold transition-colors duration-300">
                      {benefit.title}
                    </h3>
                    <p className="text-gray-400 leading-relaxed">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <button className="bg-gradient-to-r from-gold to-gold/90 text-black px-8 py-3 rounded-lg font-semibold hover:from-gold/90 hover:to-gold transition-all duration-200 transform hover:scale-105 flex items-center">
              See How It Works
              <ArrowRight className="ml-2 w-5 h-5" />
            </button>
          </div>

          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="/WhatsApp Image 2025-09-28 at 19.39.37.jpeg" 
                alt="Professional woman enjoying her morning routine while AI handles her workflow automation" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-6 -right-6 bg-gradient-to-br from-gold to-gold/80 rounded-xl p-4 shadow-lg">
              <div className="text-black font-bold text-sm">99.9% Uptime</div>
            </div>
            
            <div className="absolute -bottom-6 -left-6 bg-gradient-to-br from-gray-800 to-gray-900 border border-gold/30 rounded-xl p-4 shadow-lg">
              <div className="text-gold font-semibold text-sm">AI-Powered</div>
              <div className="text-gray-300 text-xs">Always Learning</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WorkflowTransformation;