import React from 'react';
import { Users, Award, Lightbulb, Target } from 'lucide-react';

const About = () => {
  const stats = [
    { number: '1000+', label: 'Businesses Automated', icon: Target },
    { number: '50M+', label: 'Tasks Processed Daily', icon: Lightbulb },
    { number: '99.9%', label: 'Uptime Guarantee', icon: Award },
    { number: '24/7', label: 'Expert Support', icon: Users }
  ];

  const values = [
    {
      title: 'Innovation First',
      description: 'We push the boundaries of what\'s possible with AI automation, constantly evolving our solutions to stay ahead of industry needs.'
    },
    {
      title: 'Client Success',
      description: 'Your success is our mission. We partner with you to ensure maximum ROI and seamless integration of automation solutions.'
    },
    {
      title: 'Reliable Excellence',
      description: 'Built on enterprise-grade infrastructure with 99.9% uptime, our solutions deliver consistent, dependable performance.'
    }
  ];

  return (
    <section id="about" className="py-24 bg-gradient-to-b from-black to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-16">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Leading the
              <span className="text-gold"> Automation Revolution</span>
            </h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Founded by AI pioneers and automation experts, AutomateAI is at the forefront of intelligent 
              business transformation. We combine cutting-edge machine learning with practical business 
              solutions to deliver measurable results.
            </p>
            <p className="text-lg text-gray-400 mb-8">
              Our mission is to democratize AI-powered automation, making sophisticated intelligent systems 
              accessible to businesses of all sizes. From startups to Fortune 500 companies, we've helped 
              organizations achieve unprecedented efficiency and growth.
            </p>
            <button className="bg-gradient-to-r from-gold to-gold/90 text-black px-8 py-3 rounded-lg font-semibold hover:from-gold/90 hover:to-gold transition-all duration-200 transform hover:scale-105">
              Learn Our Story
            </button>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 border border-gray-700/50 rounded-xl p-6 text-center hover:border-gold/30 transition-all duration-300"
              >
                <stat.icon className="w-8 h-8 text-gold mx-auto mb-4" />
                <div className="text-3xl font-bold text-white mb-2">{stat.number}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {values.map((value, index) => (
            <div
              key={index}
              className="text-center group"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-gold/20 to-gold/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-gold/30 group-hover:border-gold/50 transition-all duration-300">
                <div className="w-3 h-3 bg-gold rounded-full"></div>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-gold transition-colors duration-300">
                {value.title}
              </h3>
              <p className="text-gray-300 leading-relaxed">
                {value.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;