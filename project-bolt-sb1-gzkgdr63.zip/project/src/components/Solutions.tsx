import React from 'react';
import { Building, ShoppingCart, Heart, Truck, Factory, GraduationCap } from 'lucide-react';

const Solutions = () => {
  const industries = [
    {
      icon: Building,
      name: 'Finance & Banking',
      description: 'Automated compliance, fraud detection, and customer onboarding processes.',
      benefits: ['95% faster loan processing', 'Real-time fraud detection', 'Regulatory compliance automation']
    },
    {
      icon: ShoppingCart,
      name: 'E-commerce & Retail',
      description: 'Inventory management, customer service automation, and personalized marketing.',
      benefits: ['Dynamic pricing optimization', 'Automated customer support', 'Inventory forecasting']
    },
    {
      icon: Heart,
      name: 'Healthcare',
      description: 'Patient scheduling, medical record management, and diagnostic assistance.',
      benefits: ['Streamlined patient care', 'Automated appointments', 'Medical data analysis']
    },
    {
      icon: Truck,
      name: 'Logistics & Supply Chain',
      description: 'Route optimization, demand forecasting, and warehouse automation.',
      benefits: ['30% cost reduction', 'Real-time tracking', 'Predictive maintenance']
    },
    {
      icon: Factory,
      name: 'Manufacturing',
      description: 'Quality control, predictive maintenance, and production optimization.',
      benefits: ['Zero-defect manufacturing', 'Predictive maintenance', 'Energy optimization']
    },
    {
      icon: GraduationCap,
      name: 'Education & Training',
      description: 'Student assessment, curriculum optimization, and administrative automation.',
      benefits: ['Personalized learning paths', 'Automated grading', 'Student analytics']
    }
  ];

  return (
    <section id="solutions" className="py-24 bg-gradient-to-b from-gray-900 to-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Industry-Specific
            <span className="text-gold"> Solutions</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Tailored automation solutions designed for your industry's unique challenges and requirements. 
            Experience the power of specialized AI workflows.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {industries.map((industry, index) => (
            <div
              key={index}
              className="group relative bg-gradient-to-br from-gray-800/30 to-gray-900/30 backdrop-blur-sm border border-gray-700/30 rounded-2xl p-8 hover:border-gold/40 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-gold/3 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl"></div>
              
              <div className="relative">
                <div className="w-14 h-14 bg-gradient-to-br from-gold/20 to-gold/10 rounded-xl flex items-center justify-center mb-6 border border-gold/30 group-hover:border-gold/50 group-hover:scale-110 transition-all duration-300">
                  <industry.icon className="w-7 h-7 text-gold" />
                </div>
                
                <h3 className="text-xl font-bold text-white mb-4 group-hover:text-gold transition-colors duration-300">
                  {industry.name}
                </h3>
                
                <p className="text-gray-300 mb-6 leading-relaxed">
                  {industry.description}
                </p>
                
                <ul className="space-y-2">
                  {industry.benefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-start text-gray-400 text-sm">
                      <div className="w-1.5 h-1.5 bg-gold rounded-full mt-2 mr-3 flex-shrink-0"></div>
                      <span className="group-hover:text-gray-300 transition-colors duration-300">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-gold/10 via-gold/5 to-gold/10 border border-gold/20 rounded-2xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-4">
              Don't see your industry?
            </h3>
            <p className="text-gray-300 mb-6">
              Our flexible automation platform adapts to any business model. Let's discuss how we can create 
              a custom solution for your specific needs.
            </p>
            <button className="bg-gradient-to-r from-gold to-gold/90 text-black px-8 py-3 rounded-lg font-semibold hover:from-gold/90 hover:to-gold transition-all duration-200 transform hover:scale-105">
              Request Custom Solution
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Solutions;